package com.GREOT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreotServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
