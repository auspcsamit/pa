package com.GREOT.model;

import jakarta.persistence.*;

@Entity
@Table(name = "Exam_Schedule")

public class Schedule {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long s_Id;
	private Long Exam_id;
	private String date;
	private float payment;
	
	
	public Schedule() {
	}


	public Long getS_Id() {
		return s_Id;
	}


	public void setS_Id(Long s_Id) {
		this.s_Id = s_Id;
	}


	public Long getExam_id() {
		return Exam_id;
	}


	public void setExam_id(Long exam_id) {
		Exam_id = exam_id;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public float getPayment() {
		return payment;
	}


	public void setPayment(float payment) {
		this.payment = payment;
	}

	
}
