package com.GREOT.model;

import jakarta.persistence.*;

@Entity
@Table(name="Result_Table")

public class Result_table {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long R_id;
	private Long Exam_id;
	private int result;
	
	
	public Result_table() {
		
	}


	public Long getR_id() {
		return R_id;
	}


	public void setR_id(Long r_id) {
		R_id = r_id;
	}


	public Long getExam_id() {
		return Exam_id;
	}


	public void setExam_id(Long exam_id) {
		Exam_id = exam_id;
	}


	public int getResult() {
		return result;
	}


	public void setResult(int result) {
		this.result = result;
	}
	

}
