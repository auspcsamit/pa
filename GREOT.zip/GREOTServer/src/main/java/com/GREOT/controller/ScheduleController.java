package com.GREOT.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.GREOT.model.Schedule;
import com.GREOT.service.ScheduleService;

@Controller
public class ScheduleController {
	
	@Autowired
	ScheduleService scheduleService;
	
	@PostMapping("/Schedules") 
	public String addSchedule(@ModelAttribute ("schedules")Schedule schedule) {
		
		scheduleService.saveSchedule(schedule);
		return "Schedule";
		
	}
	
	@RequestMapping("/Schedulepage")
	public String SchedulePage() {
		
		return "Schedule";
		
	}
	
//	@RequestMapping("/goback")
//	public String goback() {
//		
//		return "CreateTest";
//		
//	}
	
	@RequestMapping("/ViewSchedulepage")
	public ModelAndView ViewSchedulepage() {
		
		List<Schedule> l = scheduleService.findAll();
		ModelAndView mv=new ModelAndView();
		mv.addObject("list",l);
		mv.setViewName("ViewSchedule");
		return mv;
		
	}
	
	@GetMapping("/deleteSchedule")
	public ModelAndView deleteschedule(@RequestParam("id") Long s_Id) {
		
		scheduleService.deleteSchedule(s_Id);
		List<Schedule> l=scheduleService.findAll();
		ModelAndView mv=new ModelAndView();
		mv.addObject("list",l);
		mv.setViewName("ViewSchedule");
		return mv;
		
	}
	
	@GetMapping("/updatepages")
	public ModelAndView upadteschedulePage(@RequestParam ("schedules") Long l ) 
	{
		Schedule schedule = scheduleService.findById(l);
		System.out.println(schedule.getExam_id());
		ModelAndView mv=new ModelAndView();
		mv.addObject("list",schedule);
		mv.setViewName("UpdateSchedule");
		return mv;
		
	}

}
