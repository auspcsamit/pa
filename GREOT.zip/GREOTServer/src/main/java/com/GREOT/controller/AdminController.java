package com.GREOT.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.GREOT.model.Admin;
import com.GREOT.service.AdminService;

import jakarta.servlet.http.HttpSession;


@Controller
public class AdminController {

	
@Autowired
AdminService adminService;


	@PostMapping("/Login")
	public String Check(@ModelAttribute Admin admin, Model m, HttpSession session) {
		
		String check = adminService.checkRegistration(admin.getEmail(), admin.getPassword());
		
		if(check != null)
		{
			if(check.equals("password wrong"))
			{
				m.addAttribute("msg", check);
				return "Login";
			}
			else
			{
				m.addAttribute("msg", check);
				return "CreateTest";
			}
		}
		else
		{
			String msg="User not exists....";
			m.addAttribute("msg", msg);
			return "Login";
		}
	}


	@RequestMapping("/Login")
	public String loginPage()
	{
		
		return "Login";
		
	}
	@RequestMapping("/")
	public String Homepage()
	{
		
		return "Home";
		
	}
	@GetMapping("/Registerpage")
	public String registerpage()
	{
		
		return "Registerpage";
		
	}
	
	@GetMapping("/CreateTest")
	public String createtestpage()
	{
		
		return "CreateTest";
		
	}
	
	@GetMapping("/Question")
	public String Questionpage()
	{
		
		return "Question";
		
	}
	
	@GetMapping("/ForgotPassword")
	public String frogetpassword()
	{
		
		return "ForgotPassword";
		
	}
	
	@RequestMapping("/Register")
	public String registeruser(@ModelAttribute ("registration")Admin admin, ModelMap model)
	{
		adminService.saveRegistration(admin);
		return "Login";
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session)
	{
		session.invalidate();
		return "Login";
		
	}
	
}