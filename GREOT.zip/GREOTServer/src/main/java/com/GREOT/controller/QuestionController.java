package com.GREOT.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.GREOT.model.Questions;
import com.GREOT.service.QuestionService;

@Controller
public class QuestionController {
	
	
	@Autowired
	QuestionService questionService;
	
	@PostMapping("/Questions")
	public String addQuestion(@ModelAttribute ("questions")Questions question)
	{
		questionService.saveQuestion(question);
		return "Question";
	}
	
	@RequestMapping("/Questionpage")
	public String QuestionPage()
	{
		return "Question";	
	}
	
	@RequestMapping("/goback")
	public String goback()
	{
		return "CreateTest";
	}
	
	@RequestMapping("/ViewQuestionpage")
	public ModelAndView ViewQuestionpage()
	{
		List<Questions> l = questionService.findAll();
		ModelAndView mv = new ModelAndView();
		mv.addObject("list",l);
		mv.setViewName("ViewQuestion");
		return mv;
	}
	
	@GetMapping("/delete")
	public ModelAndView deletequestion(@RequestParam("id") Long q_id)
	{
		questionService.deleteQuestion(q_id);
		List<Questions> l = questionService.findAll();
		ModelAndView mv = new ModelAndView();
		mv.addObject("list",l);
		mv.setViewName("ViewQuestion");
		return mv;
	}
	
	@GetMapping("/updatepage")
	public ModelAndView upadtequestionPage(@RequestParam ("questions") Long l ) 
	{
		Questions question = questionService.findById(l);
		System.out.println(question.getQuestion());
		ModelAndView mv = new ModelAndView();
		mv.addObject("list",question);
		mv.setViewName("UpdateQuestion");
		return mv;
	}

}