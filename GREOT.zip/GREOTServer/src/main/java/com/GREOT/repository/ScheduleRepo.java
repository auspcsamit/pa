package com.GREOT.repository;

import org.springframework.data.repository.CrudRepository;

import com.GREOT.model.Schedule;

public interface ScheduleRepo extends CrudRepository<Schedule, Long> {

}
