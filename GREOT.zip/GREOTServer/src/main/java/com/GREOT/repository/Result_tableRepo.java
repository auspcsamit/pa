package com.GREOT.repository;

import org.springframework.data.repository.CrudRepository;

import com.GREOT.model.Result_table;

public interface Result_tableRepo extends CrudRepository<Result_table, Integer> {
	
}
