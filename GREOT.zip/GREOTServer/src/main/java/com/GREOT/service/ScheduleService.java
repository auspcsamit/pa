package com.GREOT.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.GREOT.model.Schedule;
import com.GREOT.repository.ScheduleRepo;


@Service
@Transactional
public class ScheduleService {
	
	@Autowired
	ScheduleRepo scheduleRepo;
	
	public void saveSchedule(Schedule schedule) 
	{
		scheduleRepo.save(schedule);
	}
	
	
	public List<Schedule> findAll()
	{
		List<Schedule> l= (List<Schedule>) scheduleRepo.findAll();
		return l;
	}
	
	
	public void deleteSchedule(Long s_Id)
	{
		scheduleRepo.deleteById(s_Id);
	}
	
	
	public Schedule findById(Long id)
	{
		return  scheduleRepo.findById(id).get();
	}
	

}
