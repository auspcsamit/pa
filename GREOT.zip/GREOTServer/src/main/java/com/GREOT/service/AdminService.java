package com.GREOT.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.GREOT.model.Admin;
import com.GREOT.repository.AdminRepo;

@Service
@Transactional
public class AdminService 
{
	@Autowired
	AdminRepo adminRepo;
	
	public void saveRegistration(Admin admin) 
	{
		adminRepo.save(admin);
	}
	
	
	public void forgetRegistration(Admin registration)
	{
		adminRepo.save(registration);
	}
	
	
	public String checkRegistration(String email,String password)
	{
		Optional<Admin> admin = adminRepo.findByEmail(email);
		
		if(admin.isPresent())
		{
			Admin a = admin.get();
			if(a.getPassword().equals(password))
			{
				return "Successfully login";
			}
			else
			{
				return "password wrong";
			}
			
		}
		return null;
	}
}