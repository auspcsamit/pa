package com.GREOT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreotServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreotServerApplication.class, args);
	}

}
