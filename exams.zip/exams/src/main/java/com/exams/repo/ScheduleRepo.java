package com.exams.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exams.entity.Schedule;

public interface ScheduleRepo extends JpaRepository<Schedule, Integer>{

}
