package com.exams.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exams.entity.Question;

public interface QuestionRepo extends JpaRepository<Question, Integer> {

}
