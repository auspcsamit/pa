package com.exams.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.exams.entity.Admin;
import com.exams.entity.Question;
import com.exams.repo.AdminRepo;

@Controller
public class AdminController {
	
	@Autowired
	AdminRepo adminRepo;
	
	@GetMapping("/loginPage")
	public ModelAndView getloginPage()
	{
		ModelAndView mav = new ModelAndView("login");
		AdminController admin = new AdminController();
		mav.addObject("admin", admin);
		return mav;
	}
	
	@GetMapping("/home")
	public ModelAndView getHomePage()
	{
		ModelAndView mav = new ModelAndView("home");
		Question question = new Question();
		mav.addObject("newQues", question);
		return mav;
	}
	
	@GetMapping("/logout")
	public ModelAndView getHomepage()
	{
		ModelAndView mav = new ModelAndView("login");
		return mav;
	}
	
	@PostMapping("/loginCheck")
	public String loginCheck(@ModelAttribute Admin admin)
	{
		Optional<Admin> logindata = adminRepo.findById(admin.getId());
		
		if(logindata!=null && logindata.get().getPassword().equals(admin.getPassword()))
		{
			return "redirect:/home";
		}
		
		return "redirect:/loginPage";
	}

}
