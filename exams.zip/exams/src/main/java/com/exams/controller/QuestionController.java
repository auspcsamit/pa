package com.exams.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.exams.entity.Question;
import com.exams.entity.Schedule;
import com.exams.repo.QuestionRepo;
import com.exams.repo.ScheduleRepo;

@Controller
public class QuestionController {
	
	@Autowired
	QuestionRepo questionRepo;
	
	@Autowired
	ScheduleRepo scheduleRepo;
	
	
	@GetMapping("/viewQuestions")
	public ModelAndView viewQuestions()
	{
		ModelAndView mav = new ModelAndView("home");
		mav.addObject("showQuestion", true);
		List<Question> questions = questionRepo.findAll();
		mav.addObject("questions", questions);
		return mav;
	}
	
	@GetMapping("/addQuetion")
	public ModelAndView addNewQuestion()
	{
		ModelAndView mav = new ModelAndView("home");
		Question question = new Question();
		mav.addObject("showAddQuestion", true);
		mav.addObject("newQues", question);
		return mav;
	}
	
	@PostMapping("/saveQuestion")
	public String saveQuestion(@ModelAttribute Question question)
	{
		questionRepo.save(question);
		return "redirect:/viewQuestions";
	}
	
	@GetMapping("/editQuestion")
	public ModelAndView editQuestion(@RequestParam int qId)
	{
		ModelAndView mav = new ModelAndView("home");
		Optional<Question> question = questionRepo.findById(qId);
		mav.addObject("showAddQuestion", true);
		mav.addObject("newQues", question);
		return mav;
	}
	
	@GetMapping("/deleteQuestion")
	public String deleteQuestion(@RequestParam int qId)
	{
		questionRepo.deleteById(qId);
		return "redirect:/viewQuestions";
	}
	
	@GetMapping("/examSchedules")
	public ModelAndView addNewSchedule()
	{
		ModelAndView mav = new ModelAndView("home");
		Schedule schedule = new Schedule();
		mav.addObject("showScheduleForm", true);
		mav.addObject("schedule", schedule);
		return mav;
	}
	
	@PostMapping("/saveSchedule")
	public String saveSchedule(@ModelAttribute Schedule schedule)
	{
		scheduleRepo.save(schedule);
		return "redirect:/examSchedules";
	}

}
