package com.exams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
